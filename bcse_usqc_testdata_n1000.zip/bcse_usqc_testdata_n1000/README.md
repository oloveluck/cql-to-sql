# BCS-E synthetic test population (n=1,000) in US Quality Core 0.5.0, FHIR Bulk Data format

Synthetic people only. Generated 2026-11-06 by `generate.py` (seeded, reproducible).

## Contents
- `bulk/` is a FHIR Bulk Data `$export` output set: one NDJSON file per resource type plus `manifest.json`. The manifest URLs use a placeholder base (`https://bulk.example.org/...`); host the files and rewrite the base, or load the NDJSON directly (Aidbox `$import`, HAPI bulk import, or `$load`).
- `answer_key_bcse_my2025.csv` holds the expected BCS-E populations per patient: initial population, continuous enrollment, denominator, exclusion and numerator, with the edge-case ID.
- `check.py` runs the structural check against the US Quality Core 0.5.0 profile tables. `generate.py` regenerates the data.

## Measure parameters (HEDIS MY2025 BCS-E, as used in this project)
- Measurement period 2025-01-01 to 2025-12-31. Ages 42–74 at 2025-12-31.
- Female criterion: administrative gender female, or sex assigned at birth female (Observation, LOINC 76689-9 = LA3-6).
- Continuous enrollment from 2023-10-01 to 2025-12-31, with at most one gap of 45 days or less per year, and enrolled on December 31.
- Mammography from 2023-10-01 to 2025-12-31 counts toward the numerator.
- Exclusions:
  - bilateral mastectomy, or evidence of both left and right mastectomy (including two unilateral procedures at least 14 days apart, or modifier 50)
  - hospice
  - palliative care
  - death in the MP
  - frailty plus advanced illness at age 66 or older
  - gender-affirming chest surgery with gender dysphoria
- Value sets are referenced by NCQA OID. The codes in the data are representative, not a full Value Set Directory expansion.

## Totals in the answer key
1,000 patients: 612 female, 356 male, 17 other, 15 unknown. Initial population 419, eligible after enrollment 408, excluded 24, denominator 384, numerator 234 (rate 60.9%).

## Edge cases
| ID | Scenario and expected result |
|---|---|
| AGE-01 | Turns 42 on the last day of the MP (DOB 1983-12-31): in IP |
| AGE-02 | Age 41 at MP end (DOB 1984-01-01): not in IP |
| AGE-03 | Age 74 at MP end (DOB 1951-01-01): in IP |
| AGE-04 | Age 75 at MP end (DOB 1950-12-31): not in IP |
| AGE-05 | Birth date year-only (1965): not computable, not in IP |
| SEX-01 | Administrative gender male, sex assigned at birth female (LOINC 76689-9 = LA3-6): in IP |
| SEX-02 | Administrative gender female, sex assigned at birth male: in IP (administrative gender qualifies) |
| SEX-03 | Administrative gender other, no sex-at-birth observation: not in IP |
| SEX-04 | Administrative gender unknown, sex assigned at birth female: in IP |
| SEX-05 | Male, no female criterion, has a mammogram anyway: not in IP |
| SEX-06 | Sex at birth observation entered-in-error (not usable), gender male: not in IP |
| NUM-01 | Mammogram on 2023-10-01, first day of the window: numerator |
| NUM-02 | Mammogram on 2023-09-30, one day before the window: not numerator |
| NUM-03 | Mammogram on 2025-12-31, last day of the MP: numerator |
| NUM-04 | Mammogram on 2026-01-05, after the MP: not numerator |
| NUM-05 | Mammography only as DiagnosticReport Note (LOINC 24606-6, final): numerator |
| NUM-06 | Mammography report status preliminary: not numerator |
| NUM-07 | ImagingStudy only (modality MG), no Procedure or report: not numerator |
| NUM-08 | ProcedureNotDone mammography (patient declined): not numerator |
| NUM-09 | ServiceNotRequested mammography (not indicated): not numerator |
| NUM-10 | Mammography ordered (ServiceRequest active) but never performed: not numerator |
| NUM-11 | Mammography Procedure status stopped: not numerator |
| NUM-12 | Mammography Procedure entered-in-error: not numerator |
| NUM-13 | Diagnostic mammogram CPT 77065: numerator (in Mammography value set) |
| NUM-14 | Breast ultrasound CPT 76641 only: not numerator |
| NUM-15 | Screening tomosynthesis add-on 77063 with 77067: numerator |
| NUM-16 | Mammogram date month precision 2024-05: numerator (whole month inside window) |
| NUM-17 | Mammogram date year precision 2023: not numerator (may precede Oct 1) |
| NUM-18 | Mammogram as performedPeriod starting 2025-03-03: numerator |
| NUM-19 | Mammography from Claim only (paid professional claim, CPT 77067) plus Procedure from claim: numerator |
| EXC-01 | Bilateral mastectomy Procedure (SNOMED 27865001), 2015: excluded |
| EXC-02 | History of bilateral mastectomy Condition Z90.13: excluded |
| EXC-03 | Absence of left breast Z90.12 and right breast Z90.11 (two conditions): excluded |
| EXC-04 | Unilateral mastectomy left only (bodySite 7771000): not excluded |
| EXC-05 | Unilateral mastectomy with bilateral bodySite (51440002): excluded |
| EXC-06 | Two unilateral mastectomies CPT 19303, 30 days apart, no laterality: excluded |
| EXC-07 | Two unilateral mastectomies CPT 19303, 7 days apart, no laterality: not excluded (< 14 days) |
| EXC-08 | Claim CPT 19303 with modifier 50, Procedure bodySite bilateral: excluded |
| EXC-09 | Bilateral mastectomy dated 2026-02-10 (after MP): not excluded |
| EXC-10 | Z90.13 with verificationStatus refuted: not excluded |
| EXC-11 | Bilateral mastectomy Procedure entered-in-error: not excluded |
| EXC-12 | Hospice encounter in MP: excluded |
| EXC-13 | Hospice intervention (ServiceRequest, SNOMED 385763009) in MP: excluded |
| EXC-14 | Palliative care encounter (Z51.5) in MP: excluded |
| EXC-15 | Deceased 2025-08-20: excluded |
| EXC-16 | Age 70, frailty diagnosis + advanced illness (two outpatient visits with CHF): excluded |
| EXC-17 | Age 70, frailty only, no advanced illness: not excluded |
| EXC-18 | Age 60, frailty + advanced illness (under 66): not excluded |
| EXC-19 | Gender-affirming chest surgery CPT 19318 + gender dysphoria F64.0: excluded |
| EXC-20 | Hospice encounter in 2024 (before MP): not excluded |
| ENR-01 | One 30-day coverage gap in 2025: continuous enrollment met |
| ENR-02 | One 60-day coverage gap in 2025: continuous enrollment not met |
| ENR-03 | Coverage ends 2025-12-15 (not enrolled on Dec 31): not met |
| ENR-04 | Coverage starts 2024-03-01 (late for the Oct 1, 2023 start): not met |
| ENR-05 | Coverage status cancelled: not met |
| ENR-06 | Product switch Medicaid to Commercial on 2025-01-01, contiguous: met (Commercial on Dec 31) |
| ENR-07 | Two gaps of 20 days in 2024: not met (more than one gap in a year) |

## Resources in the export
| Type | Count |
|---|---|
| AdverseEvent | 64 |
| AllergyIntolerance | 114 |
| BodyStructure | 39 |
| CarePlan | 39 |
| CareTeam | 39 |
| Claim | 248 |
| ClaimResponse | 41 |
| Communication | 74 |
| CommunicationRequest | 74 |
| Condition | 1664 |
| Coverage | 1012 |
| Device | 39 |
| DeviceRequest | 64 |
| DeviceUseStatement | 39 |
| DiagnosticReport | 618 |
| Encounter | 1382 |
| FamilyMemberHistory | 96 |
| Flag | 39 |
| Goal | 39 |
| ImagingStudy | 48 |
| Immunization | 357 |
| ImmunizationEvaluation | 100 |
| ImmunizationRecommendation | 58 |
| Location | 5 |
| Medication | 2 |
| MedicationAdministration | 128 |
| MedicationDispense | 397 |
| MedicationRequest | 397 |
| MedicationStatement | 352 |
| NutritionOrder | 64 |
| Observation | 2272 |
| Organization | 8 |
| Patient | 1000 |
| Practitioner | 12 |
| PractitionerRole | 12 |
| Procedure | 377 |
| QuestionnaireResponse | 246 |
| RelatedPerson | 47 |
| ServiceRequest | 47 |
| Substance | 1 |
| Task | 116 |

## US Quality Core profiles used (all 57 resource profiles)
| Profile | Resources |
|---|---|
| `us-quality-core-adverseevent` | 64 |
| `us-quality-core-allergyintolerance` | 114 |
| `us-quality-core-bodystructure` | 39 |
| `us-quality-core-careplan` | 39 |
| `us-quality-core-careteam` | 39 |
| `us-quality-core-claim` | 248 |
| `us-quality-core-claimresponse` | 41 |
| `us-quality-core-communication` | 46 |
| `us-quality-core-communicationnotdone` | 28 |
| `us-quality-core-communicationrequest` | 74 |
| `us-quality-core-condition-encounter-diagnosis` | 1379 |
| `us-quality-core-condition-problems-health-concerns` | 285 |
| `us-quality-core-coverage` | 1012 |
| `us-quality-core-device` | 39 |
| `us-quality-core-devicenotrequested` | 25 |
| `us-quality-core-devicerequest` | 39 |
| `us-quality-core-deviceusestatement` | 39 |
| `us-quality-core-diagnosticreport-lab` | 577 |
| `us-quality-core-diagnosticreport-note` | 41 |
| `us-quality-core-encounter` | 1382 |
| `us-quality-core-familymemberhistory` | 96 |
| `us-quality-core-flag` | 39 |
| `us-quality-core-goal` | 39 |
| `us-quality-core-imagingstudy` | 48 |
| `us-quality-core-immunization` | 307 |
| `us-quality-core-immunizationevaluation` | 100 |
| `us-quality-core-immunizationnotdone` | 50 |
| `us-quality-core-immunizationrecommendation` | 58 |
| `us-quality-core-location` | 5 |
| `us-quality-core-medication` | 2 |
| `us-quality-core-medicationadministration` | 64 |
| `us-quality-core-medicationadministrationnotdone` | 64 |
| `us-quality-core-medicationdispense` | 352 |
| `us-quality-core-medicationdispensedeclined` | 45 |
| `us-quality-core-medicationnotrequested` | 45 |
| `us-quality-core-medicationrequest` | 352 |
| `us-quality-core-medicationstatement` | 352 |
| `us-quality-core-nonpatient-observation` | 5 |
| `us-quality-core-nutritionorder` | 64 |
| `us-quality-core-observation-clinical-result` | 1000 |
| `us-quality-core-observation-lab` | 577 |
| `us-quality-core-observation-screening-assessment` | 246 |
| `us-quality-core-observationcancelled` | 89 |
| `us-quality-core-organization` | 8 |
| `us-quality-core-patient` | 1000 |
| `us-quality-core-practitioner` | 12 |
| `us-quality-core-practitionerrole` | 12 |
| `us-quality-core-procedure` | 375 |
| `us-quality-core-procedurenotdone` | 2 |
| `us-quality-core-questionnaireresponse` | 246 |
| `us-quality-core-relatedperson` | 47 |
| `us-quality-core-servicenotrequested` | 2 |
| `us-quality-core-servicerequest` | 45 |
| `us-quality-core-simple-observation` | 355 |
| `us-quality-core-substance` | 1 |
| `us-quality-core-task` | 58 |
| `us-quality-core-taskrejected` | 58 |

The 7 USQC extensions also appear: recorded, notDoneValueSet, notDoneReason, doNotPerformReason, encounter-diagnosisPresentOnAdmission, isElective and servicerequest-appropriatenessScore.

## Validation
`check.py` reports no structural issues on the 11,770 resources. It checks:
- cardinality
- fixed status codes on the negation profiles
- required bindings to the USQC value sets that ship with expansions
- reference integrity
- unique IDs

It is not the HL7 FHIR Validator: it does not run FHIRPath invariants, slicing discriminators or a terminology server. Run the HL7 validator with `-ig fhir.onc.us-quality-core#0.5.0` before you rely on full conformance.

## Notes
- The answer key comes from the scenario design, not from running a measure engine. Use it to test the CQL and the SQL on FHIR implementations against each other.
- ImagingStudy, ServiceRequest (ordered), ProcedureNotDone and ServiceNotRequested mammography are deliberately not numerator evidence.
