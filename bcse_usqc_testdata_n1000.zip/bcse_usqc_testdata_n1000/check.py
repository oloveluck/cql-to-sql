"""Structural conformance check of the bulk output against US Quality Core 0.5.0 profile tables (IG CSV snapshots).

Checks per resource: declared profile exists; cardinality (min/max) of first-level elements and of second-level
elements whose parent is present (non-sliced); choice elements [x]; fixed/pattern codes on status-type elements;
required bindings to the USQC ValueSets shipped with expansions; reference integrity across the export; unique ids.
Not a replacement for the HL7 FHIR Validator (no FHIRPath invariants, slicing discriminators or terminology server).
"""
import collections, csv, glob, json, pathlib, re, sys

BULK = pathlib.Path(sys.argv[1]); CSVS = pathlib.Path(sys.argv[2]); EXP = pathlib.Path(sys.argv[3])
USQC = "http://fhir.org/guides/onc/us-quality-core/StructureDefinition/"
prof = {}
for f in glob.glob(str(CSVS / "StructureDefinition-*.csv")):
    pid = f.split("StructureDefinition-")[1][:-4]
    prof[USQC + pid] = list(csv.DictReader(open(f)))
exp = {}
for e in json.load(open(EXP))["entry"]:
    r = e["resource"]
    exp[r["url"]] = {c["code"] for c in r["expansion"].get("contains", [])}
BASE_REQ = {  # small set of base required value sets (FHIR R4 codes) used in this data
    "http://hl7.org/fhir/ValueSet/administrative-gender": {"male", "female", "other", "unknown"},
    "http://hl7.org/fhir/ValueSet/fm-status": {"active", "cancelled", "draft", "entered-in-error"},
    "http://hl7.org/fhir/ValueSet/encounter-status": {"planned", "arrived", "triaged", "in-progress", "onleave", "finished", "cancelled", "entered-in-error", "unknown"},
    "http://hl7.org/fhir/ValueSet/diagnostic-report-status": {"registered", "partial", "preliminary", "final", "amended", "corrected", "appended", "cancelled", "entered-in-error", "unknown"},
    "http://hl7.org/fhir/ValueSet/request-status": {"draft", "active", "on-hold", "revoked", "completed", "entered-in-error", "unknown"},
    "http://hl7.org/fhir/ValueSet/request-intent": {"proposal", "plan", "directive", "order", "original-order", "reflex-order", "filler-order", "instance-order", "option"},
}
issues = collections.Counter(); examples = {}
def issue(k, msg):
    issues[k] += 1; examples.setdefault(k, msg)

def present(res, path):
    """path relative to resource, e.g. 'status' or 'performed[x]' or 'code.coding'."""
    parts = path.split(".")
    cur = [res]
    for p in parts:
        nxt = []
        for c in cur:
            if not isinstance(c, dict):
                continue
            if p.endswith("[x]"):
                stem = p[:-3]
                for k, v in c.items():
                    if k.startswith(stem) and k[len(stem):len(stem)+1].isupper():
                        nxt.extend(v if isinstance(v, list) else [v])
            elif p in c:
                v = c[p]; nxt.extend(v if isinstance(v, list) else [v])
            elif "_" + p in c:
                nxt.append(c["_" + p])
        cur = nxt
    return cur

ids = collections.Counter(); allres = []
for f in sorted(BULK.glob("*.ndjson")):
    for line in open(f):
        r = json.loads(line); allres.append(r); ids[(r["resourceType"], r["id"])] += 1
for k, v in ids.items():
    if v > 1: issue("duplicate-id", f"{k} x{v}")
keys = set(ids)
for r in allres:
    ps = r.get("meta", {}).get("profile", [])
    if not ps or ps[0] not in prof:
        issue("unknown-profile", f"{r['resourceType']}/{r['id']} {ps}"); continue
    rows = prof[ps[0]]
    base = rows[0]["Path"]
    if base != r["resourceType"]:
        issue("profile-type-mismatch", f"{r['resourceType']} vs {base}")
    for x in rows:
        path = x["Path"]
        if "." not in path or x["Slice Name"]:
            continue
        rel = path[len(base) + 1:]
        depth = rel.count(".")
        if depth > 1:
            continue
        if depth == 1 and not present(r, rel.split(".")[0]):
            continue
        if depth == 1:   # check within each parent instance
            parents = present(r, rel.split(".")[0]); vals_per = [present(p, rel.split(".")[1]) for p in parents]
        else:
            vals_per = [present(r, rel)]
        mn = int(x["Min"] or 0); mx = x["Max"]
        for vals in vals_per:
            if len(vals) < mn:
                issue(f"min:{ps[0].split('/')[-1]}:{rel}", f"{r['resourceType']}/{r['id']}")
            if mx not in ("*", "") and len(vals) > int(mx):
                issue(f"max:{ps[0].split('/')[-1]}:{rel}", f"{r['resourceType']}/{r['id']}")
            if x["Binding Strength"] == "required" and vals and x["Type(s)"].startswith("code"):
                vs = x["Binding Value Set"].split("|")[0]
                allowed = exp.get(vs) or BASE_REQ.get(vs)
                if allowed is not None:
                    for v in vals:
                        if isinstance(v, str) and v not in allowed:
                            issue(f"binding:{ps[0].split('/')[-1]}:{rel}", f"{r['resourceType']}/{r['id']} value {v} not in {vs}")
            fx = (x["Fixed Value"] or x["Pattern"]).strip()
            m = re.search(r'<valueCode xmlns="http://hl7.org/fhir" value="([^"]+)"', fx)
            if m and vals and vals[0] != m.group(1):
                issue(f"fixed:{ps[0].split('/')[-1]}:{rel}", f"{r['resourceType']}/{r['id']} {vals[0]} != {m.group(1)}")
            mb = re.search(r'<valueBoolean xmlns="http://hl7.org/fhir" value="([^"]+)"', fx)
            if mb and vals and str(vals[0]).lower() != mb.group(1) and x["Path"].endswith("doNotPerform"):
                issue(f"fixed:{ps[0].split('/')[-1]}:{rel}", f"{r['resourceType']}/{r['id']}")
    # references
    def walk(o):
        if isinstance(o, dict):
            if "reference" in o and isinstance(o["reference"], str) and "/" in o["reference"] and not o["reference"].startswith("http"):
                t, i = o["reference"].split("/", 1)
                if (t, i) not in keys:
                    issue("dangling-reference", f"{r['resourceType']}/{r['id']} -> {o['reference']}")
            for v in o.values(): walk(v)
        elif isinstance(o, list):
            for v in o: walk(v)
    walk(r)
print(f"resources checked: {len(allres)}")
if not issues:
    print("no structural issues found")
for k, v in issues.most_common():
    print(f"{v:6d}  {k}   e.g. {examples[k]}")
