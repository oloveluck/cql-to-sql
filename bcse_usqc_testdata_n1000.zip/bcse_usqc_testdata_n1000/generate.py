"""BCS-E (HEDIS MY2025, ECDS) synthetic test population, n=1000, as a FHIR Bulk Data ($export) output set.

- Generic US population of women, men and a few other/unknown administrative genders, ages 18-90.
- Every resource declares a US Quality Core 0.5.0 profile; every USQC resource profile is used.
- ~60 scripted BCS-E edge cases (age, sex, window, negation, exclusions, enrollment) plus routine members.
- Writes one NDJSON file per resource type + a Bulk Data manifest, an answer key (expected populations) and a
  profile-coverage report. Synthetic data only; no real people.
"""
import collections, datetime as dt, json, pathlib, random, sys, uuid

OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "out")
BASE_URL = "https://bulk.example.org/fhir/bulkfiles/bcse-usqc-n1000/"     # placeholder file server
R = random.Random(20251231)
NS = uuid.UUID("6f1d2a3c-0b7e-4c1a-9a55-bc5e2025a001")

MP_START, MP_END = dt.date(2025, 1, 1), dt.date(2025, 12, 31)
LOOKBACK = dt.date(2023, 10, 1)
CE_START = dt.date(2023, 10, 1)            # participation: Oct 1 two years prior through end of MP
USQC = "http://fhir.org/guides/onc/us-quality-core/StructureDefinition/"
EXT_RECORDED = USQC + "us-quality-core-recorded"
EXT_NOTDONE_VS = USQC + "us-quality-core-notDoneValueSet"
EXT_NOTDONE_REASON = USQC + "us-quality-core-notDoneReason"
EXT_DNP_REASON = USQC + "us-quality-core-doNotPerformReason"
EXT_POA = USQC + "us-quality-core-encounter-diagnosisPresentOnAdmission"
EXT_ELECTIVE = USQC + "us-quality-core-isElective"
EXT_APPROP = USQC + "us-quality-core-servicerequest-appropriatenessScore"
CPT, SCT, LOINC, ICD10, RXN, CVX, HCPCS = ("http://www.ama-assn.org/go/cpt", "http://snomed.info/sct", "http://loinc.org",
                                         "http://hl7.org/fhir/sid/icd-10-cm", "http://www.nlm.nih.gov/research/umls/rxnorm",
                                         "http://hl7.org/fhir/sid/cvx", "https://www.cms.gov/Medicare/Coding/HCPCSReleaseCodeSets")
UCUM = "http://unitsofmeasure.org"
VS = {  # NCQA HEDIS MY2025 value set OIDs (as bound in valueset_bindings.csv)
    "Mammography": "urn:oid:2.16.840.1.113883.3.464.1004.1168"}

store = collections.defaultdict(list)
profiles_used = collections.Counter()
answer = []


def rid(*parts):
    return str(uuid.uuid5(NS, "/".join(map(str, parts))))


def cc(system, code, display=None, text=None):
    c = {"system": system, "code": code}
    if display:
        c["display"] = display
    out = {"coding": [c]}
    if text:
        out["text"] = text
    return out


def ref(rt, i, display=None):
    r = {"reference": f"{rt}/{i}"}
    if display:
        r["display"] = display
    return r


def add(res, profile):
    res.setdefault("meta", {})["profile"] = [USQC + profile]
    res["meta"]["source"] = "urn:sonian:bcse-testdata#synthetic"
    store[res["resourceType"]].append(res)
    profiles_used[profile] += 1
    return res


def iso(d):
    return d.isoformat()


def dtm(d, hh=10):
    return f"{d.isoformat()}T{hh:02d}:00:00-05:00"


def rand_date(a, b):
    return a + dt.timedelta(days=R.randint(0, (b - a).days))


# ------------------------------------------------------------------ shared resources
ORG_PAYERS = [("payer-com", "Summit Health Plan", "5", "PRIVATE HEALTH INSURANCE"),
              ("payer-mcr", "Summit Medicare Advantage", "1", "MEDICARE"),
              ("payer-mcd", "Summit Community Medicaid", "2", "MEDICAID")]
for oid, name, _, _ in ORG_PAYERS:
    add({"resourceType": "Organization", "id": oid, "active": True, "name": name,
         "identifier": [{"use": "official", "system": "urn:oid:2.16.840.1.113883.6.300", "value": str(R.randint(10000, 99999))}],
         "type": [cc("http://terminology.hl7.org/CodeSystem/organization-type", "pay", "Payer")]},
        "us-quality-core-organization")
FACILITIES = []
for i, (name, city, st) in enumerate([("Riverside Medical Center", "Columbus", "OH"), ("Lakeshore Imaging", "Chicago", "IL"),
                                      ("Desert Valley Clinic", "Phoenix", "AZ"), ("Harbor Community Health", "Baltimore", "MD"),
                                      ("Pine Ridge Hospice", "Asheville", "NC")]):
    oid = f"org-fac-{i+1}"
    add({"resourceType": "Organization", "id": oid, "active": True, "name": name,
         "identifier": [{"use": "official", "system": "http://hl7.org/fhir/sid/us-npi", "value": f"19{R.randint(10000000, 99999999)}"}],
         "address": [{"line": [f"{100+i*11} Main St"], "city": city, "state": st, "postalCode": f"{R.randint(10000, 99999)}"}]},
        "us-quality-core-organization")
    lid = f"loc-{i+1}"
    add({"resourceType": "Location", "id": lid, "status": "active", "name": name + " - Main",
         "managingOrganization": ref("Organization", oid), "address": {"city": city, "state": st}},
        "us-quality-core-location")
    FACILITIES.append((oid, lid))
PRACT = []
for i in range(12):
    pid = f"pract-{i+1}"
    npi = f"1{R.randint(100000000, 999999999)}"
    add({"resourceType": "Practitioner", "id": pid,
         "identifier": [{"use": "official", "system": "http://hl7.org/fhir/sid/us-npi", "value": npi}],
         "name": [{"family": R.choice(["Okafor", "Lindqvist", "Ramirez", "Chen", "Patel", "Brooks", "Nakamura", "Haddad"]),
                   "given": [R.choice(["Ana", "Sam", "Lee", "Rita", "Omar", "June"])], "prefix": ["Dr."]}]},
        "us-quality-core-practitioner")
    org, loc = FACILITIES[i % len(FACILITIES)]
    add({"resourceType": "PractitionerRole", "id": f"role-{i+1}", "active": True,
         "identifier": [{"use": "official", "system": "urn:sonian:practitioner-role", "value": f"PR{i+1:03d}"}],
         "period": {"start": "2015-01-01"}, "practitioner": ref("Practitioner", pid), "organization": ref("Organization", org),
         "location": [ref("Location", loc)],
         "code": [cc("http://nucc.org/provider-taxonomy", R.choice(["207Q00000X", "2085R0202X", "207V00000X"]))]},
        "us-quality-core-practitionerrole")
    PRACT.append(pid)
add({"resourceType": "Medication", "id": "med-lisinopril", "code": cc(RXN, "314076", "lisinopril 10 MG Oral Tablet")}, "us-quality-core-medication")
add({"resourceType": "Medication", "id": "med-letrozole", "code": cc(RXN, "200064", "letrozole 2.5 MG Oral Tablet")}, "us-quality-core-medication")
add({"resourceType": "Substance", "id": "subst-latex", "code": cc(SCT, "111088007", "Latex (substance)")}, "us-quality-core-substance")
# non-patient observations (equipment availability) at facility level
for i, (org, loc) in enumerate(FACILITIES):
    add({"resourceType": "Observation", "id": f"nonpatient-mammo-unit-{i+1}", "status": "final",
         "category": [cc(SCT, "49062001", "Device (physical object)")],
         "code": cc(SCT, "71651007", "Mammography", text="Mammography unit availability"),
         "subject": ref("Location", loc), "effectiveDateTime": "2025-06-30",
         "valueCodeableConcept": cc(SCT, "735333005", "Equipment available (finding)")},
        "us-quality-core-nonpatient-observation")

FIRST_F = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Maria", "Aisha", "Mei", "Priya", "Lucia", "Grace", "Sofia", "Hannah", "Nia", "Rosa", "Yuki"]
FIRST_M = ["James", "Robert", "Michael", "David", "Carlos", "Wei", "Arjun", "Malik", "Thomas", "Daniel", "Luis", "Kenji", "Samuel", "Omar"]
FIRST_X = ["Alex", "Jordan", "Taylor", "Riley", "Casey", "Morgan"]
LAST = ["Smith", "Johnson", "Williams", "Brown", "Garcia", "Martinez", "Nguyen", "Kim", "Patel", "Chen", "Jackson", "Lopez", "Davis",
        "Wilson", "Anderson", "Thomas", "Moore", "Lee", "Harris", "Clark", "Young", "Rivera", "Begay", "Kahale", "Okonkwo"]
STATES = [("OH", "Columbus"), ("IL", "Chicago"), ("AZ", "Phoenix"), ("MD", "Baltimore"), ("NC", "Asheville"), ("TX", "Austin"),
          ("WA", "Seattle"), ("NY", "Buffalo"), ("GA", "Macon"), ("CO", "Denver")]
RACE = [("2106-3", "White"), ("2054-5", "Black or African American"), ("2028-9", "Asian"), ("1002-5", "American Indian or Alaska Native"),
        ("2076-8", "Native Hawaiian or Other Pacific Islander"), ("2131-1", "Other Race"), ("UNK", "Unknown")]


# ------------------------------------------------------------------ edge-case catalog
# Each: (id, count, description, overrides) ; overrides applied in build_patient()
def dob_for_age(age_at_mp_end, month=6, day=15):
    return dt.date(MP_END.year - age_at_mp_end, month, day)


EDGES = [
    # age boundaries (age at Dec 31, 2025; IP 42-74)
    ("AGE-01", 2, "Turns 42 on the last day of the MP (DOB 1983-12-31): in IP", dict(dob=dt.date(1983, 12, 31), mammo=True)),
    ("AGE-02", 2, "Age 41 at MP end (DOB 1984-01-01): not in IP", dict(dob=dt.date(1984, 1, 1), mammo=True)),
    ("AGE-03", 2, "Age 74 at MP end (DOB 1951-01-01): in IP", dict(dob=dt.date(1951, 1, 1))),
    ("AGE-04", 2, "Age 75 at MP end (DOB 1950-12-31): not in IP", dict(dob=dt.date(1950, 12, 31), mammo=True)),
    ("AGE-05", 1, "Birth date year-only (1965): not computable, not in IP", dict(dob_partial="1965", mammo=True)),
    # sex criteria
    ("SEX-01", 3, "Administrative gender male, sex assigned at birth female (LOINC 76689-9 = LA3-6): in IP", dict(gender="male", saab="female", mammo=True)),
    ("SEX-02", 2, "Administrative gender female, sex assigned at birth male: in IP (administrative gender qualifies)", dict(gender="female", saab="male")),
    ("SEX-03", 2, "Administrative gender other, no sex-at-birth observation: not in IP", dict(gender="other", mammo=True)),
    ("SEX-04", 2, "Administrative gender unknown, sex assigned at birth female: in IP", dict(gender="unknown", saab="female")),
    ("SEX-05", 2, "Male, no female criterion, has a mammogram anyway: not in IP", dict(gender="male", mammo=True)),
    ("SEX-06", 2, "Sex at birth observation entered-in-error (not usable), gender male: not in IP", dict(gender="male", saab="female", saab_status="entered-in-error")),
    # numerator window and evidence form
    ("NUM-01", 2, "Mammogram on 2023-10-01, first day of the window: numerator", dict(mammo_date=dt.date(2023, 10, 1))),
    ("NUM-02", 2, "Mammogram on 2023-09-30, one day before the window: not numerator", dict(mammo_date=dt.date(2023, 9, 30))),
    ("NUM-03", 2, "Mammogram on 2025-12-31, last day of the MP: numerator", dict(mammo_date=dt.date(2025, 12, 31))),
    ("NUM-04", 2, "Mammogram on 2026-01-05, after the MP: not numerator", dict(mammo_date=dt.date(2026, 1, 5))),
    ("NUM-05", 3, "Mammography only as DiagnosticReport Note (LOINC 24606-6, final): numerator", dict(mammo_form="report")),
    ("NUM-06", 2, "Mammography report status preliminary: not numerator", dict(mammo_form="report", report_status="preliminary")),
    ("NUM-07", 2, "ImagingStudy only (modality MG), no Procedure or report: not numerator", dict(mammo_form="imagingstudy")),
    ("NUM-08", 2, "ProcedureNotDone mammography (patient declined): not numerator", dict(mammo_form="notdone")),
    ("NUM-09", 2, "ServiceNotRequested mammography (not indicated): not numerator", dict(mammo_form="notrequested")),
    ("NUM-10", 2, "Mammography ordered (ServiceRequest active) but never performed: not numerator", dict(mammo_form="order_only")),
    ("NUM-11", 2, "Mammography Procedure status stopped: not numerator", dict(mammo_status="stopped")),
    ("NUM-12", 2, "Mammography Procedure entered-in-error: not numerator", dict(mammo_status="entered-in-error")),
    ("NUM-13", 2, "Diagnostic mammogram CPT 77065: numerator (in Mammography value set)", dict(mammo_code=("77065", "Diagnostic mammography, unilateral"))),
    ("NUM-14", 2, "Breast ultrasound CPT 76641 only: not numerator", dict(mammo_code=("76641", "Ultrasound, breast, unilateral, complete"), mammo_not_vs=True)),
    ("NUM-15", 2, "Screening tomosynthesis add-on 77063 with 77067: numerator", dict(mammo_code=("77067", "Screening mammography, bilateral"), tomo=True)),
    ("NUM-16", 2, "Mammogram date month precision 2024-05: numerator (whole month inside window)", dict(mammo_partial="2024-05")),
    ("NUM-17", 2, "Mammogram date year precision 2023: not numerator (may precede Oct 1)", dict(mammo_partial="2023")),
    ("NUM-18", 2, "Mammogram as performedPeriod starting 2025-03-03: numerator", dict(mammo_period=True)),
    ("NUM-19", 2, "Mammography from Claim only (paid professional claim, CPT 77067) plus Procedure from claim: numerator", dict(mammo_claim=True)),
    # exclusions
    ("EXC-01", 2, "Bilateral mastectomy Procedure (SNOMED 27865001), 2015: excluded", dict(excl="bilat_proc")),
    ("EXC-02", 2, "History of bilateral mastectomy Condition Z90.13: excluded", dict(excl="hx_bilat")),
    ("EXC-03", 2, "Absence of left breast Z90.12 and right breast Z90.11 (two conditions): excluded", dict(excl="absent_lr")),
    ("EXC-04", 2, "Unilateral mastectomy left only (bodySite 7771000): not excluded", dict(excl="uni_left")),
    ("EXC-05", 2, "Unilateral mastectomy with bilateral bodySite (51440002): excluded", dict(excl="uni_bilat_site")),
    ("EXC-06", 2, "Two unilateral mastectomies CPT 19303, 30 days apart, no laterality: excluded", dict(excl="two_uni_30")),
    ("EXC-07", 2, "Two unilateral mastectomies CPT 19303, 7 days apart, no laterality: not excluded (< 14 days)", dict(excl="two_uni_7")),
    ("EXC-08", 2, "Claim CPT 19303 with modifier 50, Procedure bodySite bilateral: excluded", dict(excl="claim_mod50")),
    ("EXC-09", 2, "Bilateral mastectomy dated 2026-02-10 (after MP): not excluded", dict(excl="bilat_after")),
    ("EXC-10", 2, "Z90.13 with verificationStatus refuted: not excluded", dict(excl="hx_refuted")),
    ("EXC-11", 2, "Bilateral mastectomy Procedure entered-in-error: not excluded", dict(excl="bilat_eie")),
    ("EXC-12", 2, "Hospice encounter in MP: excluded", dict(excl="hospice_enc")),
    ("EXC-13", 2, "Hospice intervention (ServiceRequest, SNOMED 385763009) in MP: excluded", dict(excl="hospice_sr")),
    ("EXC-14", 2, "Palliative care encounter (Z51.5) in MP: excluded", dict(excl="palliative")),
    ("EXC-15", 2, "Deceased 2025-08-20: excluded", dict(excl="deceased")),
    ("EXC-16", 2, "Age 70, frailty diagnosis + advanced illness (two outpatient visits with CHF): excluded", dict(age=70, excl="frail_ai")),
    ("EXC-17", 2, "Age 70, frailty only, no advanced illness: not excluded", dict(age=70, excl="frail_only")),
    ("EXC-18", 2, "Age 60, frailty + advanced illness (under 66): not excluded", dict(age=60, excl="frail_ai")),
    ("EXC-19", 2, "Gender-affirming chest surgery CPT 19318 + gender dysphoria F64.0: excluded", dict(gender="male", saab="female", excl="gac")),
    ("EXC-20", 1, "Hospice encounter in 2024 (before MP): not excluded", dict(excl="hospice_prior")),
    # enrollment
    ("ENR-01", 3, "One 30-day coverage gap in 2025: continuous enrollment met", dict(cov="gap30")),
    ("ENR-02", 3, "One 60-day coverage gap in 2025: continuous enrollment not met", dict(cov="gap60", mammo=True)),
    ("ENR-03", 2, "Coverage ends 2025-12-15 (not enrolled on Dec 31): not met", dict(cov="end_early", mammo=True)),
    ("ENR-04", 2, "Coverage starts 2024-03-01 (late for the Oct 1, 2023 start): not met", dict(cov="late_start", mammo=True)),
    ("ENR-05", 2, "Coverage status cancelled: not met", dict(cov="cancelled", mammo=True)),
    ("ENR-06", 2, "Product switch Medicaid to Commercial on 2025-01-01, contiguous: met (Commercial on Dec 31)", dict(cov="switch")),
    ("ENR-07", 2, "Two gaps of 20 days in 2024: not met (more than one gap in a year)", dict(cov="two_gaps", mammo=True)),
]


def coverage_spans(kind, sopt):
    """Returns list of (start, end, status, sopt)."""
    s0 = dt.date(2022, 1, 1)
    if kind == "gap30":
        return [(s0, dt.date(2025, 3, 31), "active", sopt), (dt.date(2025, 5, 1), None, "active", sopt)]
    if kind == "gap60":
        return [(s0, dt.date(2025, 3, 31), "active", sopt), (dt.date(2025, 6, 1), None, "active", sopt)]
    if kind == "end_early":
        return [(s0, dt.date(2025, 12, 15), "active", sopt)]
    if kind == "late_start":
        return [(dt.date(2024, 3, 1), None, "active", sopt)]
    if kind == "cancelled":
        return [(s0, None, "cancelled", sopt)]
    if kind == "switch":
        return [(s0, dt.date(2024, 12, 31), "active", "2"), (dt.date(2025, 1, 1), None, "active", "5")]
    if kind == "two_gaps":
        return [(s0, dt.date(2024, 3, 31), "active", sopt), (dt.date(2024, 4, 21), dt.date(2024, 8, 31), "active", sopt),
                (dt.date(2024, 9, 21), None, "active", sopt)]
    return [(s0, None, "active", sopt)]


def ce_met(spans):
    """HEDIS-style: covered Oct 1 2023 - Dec 31 2025 with <= 1 gap of <= 45 days per calendar year, enrolled on Dec 31 2025."""
    act = sorted((s, e or dt.date(9999, 12, 31)) for s, e, st, _ in spans if st == "active")
    if not act or act[0][0] > CE_START or act[-1][1] < MP_END:
        return False
    gaps = []
    cur_end = act[0][1]
    for s, e in act[1:]:
        if s > cur_end + dt.timedelta(days=1):
            gaps.append((cur_end + dt.timedelta(days=1), s - dt.timedelta(days=1)))
        cur_end = max(cur_end, e)
    for y in (2023, 2024, 2025):
        g = [(a, b) for a, b in gaps if a.year == y]
        if len(g) > 1 or any((b - a).days + 1 > 45 for a, b in g):
            return False
    return True


# ------------------------------------------------------------------ builders
def build_patient(n, scenario, edge=None, ov=None):
    ov = ov or {}
    pid = f"bcse-{n:04d}"
    gender = ov.get("gender") or scenario["gender"]
    age = ov.get("age") or scenario["age"]
    dob = ov.get("dob") or dob_for_age(age, R.randint(1, 12), R.randint(1, 28))
    age_end = MP_END.year - dob.year - ((MP_END.month, MP_END.day) < (dob.month, dob.day))
    st, city = R.choice(STATES)
    race = R.choice(RACE)
    first = R.choice(FIRST_F if gender == "female" else FIRST_M if gender == "male" else FIRST_X)
    pat = {"resourceType": "Patient", "id": pid,
           "identifier": [{"type": cc("http://terminology.hl7.org/CodeSystem/v2-0203", "MB"), "system": "urn:sonian:member-id", "value": f"M{n:06d}"},
                          {"type": cc("http://terminology.hl7.org/CodeSystem/v2-0203", "MR"), "system": "urn:sonian:mrn", "value": f"MRN{700000+n}"}],
           "name": [{"family": R.choice(LAST), "given": [first]}], "gender": gender,
           "birthDate": ov.get("dob_partial") or iso(dob),
           "address": [{"line": [f"{R.randint(10, 9999)} {R.choice(['Oak', 'Maple', 'Cedar', 'Elm', 'Lake'])} St"], "city": city, "state": st,
                        "postalCode": f"{R.randint(10000, 99999)}"}],
           "telecom": [{"system": "phone", "value": f"555-{R.randint(100, 999)}-{R.randint(1000, 9999)}", "use": "home"}],
           "communication": [{"language": cc("urn:ietf:bcp:47", R.choice(["en", "en", "en", "es", "zh", "vi"])), "preferred": True}],
           "extension": [{"url": "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race",
                          "extension": ([{"url": "ombCategory", "valueCoding": {"system": "urn:oid:2.16.840.1.113883.6.238", "code": race[0], "display": race[1]}}]
                                        if race[0] != "UNK" else
                                        [{"url": "ombCategory", "valueCoding": {"system": "http://terminology.hl7.org/CodeSystem/v3-NullFlavor", "code": "UNK", "display": "Unknown"}}])
                                       + [{"url": "text", "valueString": race[1]}]}]}
    if ov.get("excl") == "deceased":
        pat["deceasedDateTime"] = "2025-08-20"
    add(pat, "us-quality-core-patient")
    sopt = "1" if age_end >= 65 and R.random() < 0.8 else ("2" if R.random() < 0.2 else "5")
    payer = {"1": "payer-mcr", "2": "payer-mcd", "5": "payer-com"}
    spans = coverage_spans(ov.get("cov"), sopt)
    for i, (s, e, stt, so) in enumerate(spans):
        add({"resourceType": "Coverage", "id": rid(pid, "cov", i), "status": stt,
             "identifier": [{"type": cc("http://terminology.hl7.org/CodeSystem/v2-0203", "MB"), "system": "urn:sonian:member-id", "value": f"M{n:06d}"}],
             "type": cc("https://nahdo.org/sopt", so, {"1": "MEDICARE", "2": "MEDICAID", "5": "PRIVATE HEALTH INSURANCE"}[so]),
             "subscriberId": f"M{n:06d}", "beneficiary": ref("Patient", pid),
             "relationship": cc("http://terminology.hl7.org/CodeSystem/subscriber-relationship", "self"),
             "period": {"start": iso(s), **({"end": iso(e)} if e else {})}, "payor": [ref("Organization", payer[so])],
             "class": [{"type": cc("http://terminology.hl7.org/CodeSystem/coverage-class", "plan"), "value": f"PLAN-{so}0{1 + n % 2}"}]},
            "us-quality-core-coverage")
    ctx = {"pid": pid, "n": n, "gender": gender, "age": age_end, "dob": dob, "spans": spans, "cov_ids": [rid(pid, "cov", i) for i in range(len(spans))],
           "pract": R.choice(PRACT), "fac": R.choice(FACILITIES)}
    return ctx


def encounter(ctx, d, code=("99213", "Office or other outpatient visit"), system=CPT, cls="AMB", status="finished", key="enc", dx=None, end=None):
    eid = rid(ctx["pid"], key, d)
    e = {"resourceType": "Encounter", "id": eid, "status": status,
         "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode", "code": cls},
         "type": [cc(system, code[0], code[1])], "subject": ref("Patient", ctx["pid"]),
         "participant": [{"individual": ref("Practitioner", ctx["pract"])}],
         "period": {"start": dtm(d, 9), "end": dtm(end or d, 10)}, "serviceProvider": ref("Organization", ctx["fac"][0]),
         "location": [{"location": ref("Location", ctx["fac"][1])}]}
    add(e, "us-quality-core-encounter")
    if dx:
        cid = rid(ctx["pid"], key, d, "dx")
        add({"resourceType": "Condition", "id": cid,
             "category": [cc("http://terminology.hl7.org/CodeSystem/condition-category", "encounter-diagnosis", "Encounter Diagnosis")],
             "clinicalStatus": cc("http://terminology.hl7.org/CodeSystem/condition-clinical", "active"),
             "verificationStatus": cc("http://terminology.hl7.org/CodeSystem/condition-ver-status", "confirmed"),
             "code": cc(ICD10, dx[0], dx[1]), "subject": ref("Patient", ctx["pid"]), "encounter": ref("Encounter", eid),
             "onsetDateTime": iso(d), "recordedDate": iso(d)}, "us-quality-core-condition-encounter-diagnosis")
        e["diagnosis"] = [{"condition": ref("Condition", cid), "rank": 1}]
        if cls == "IMP":
            e["diagnosis"][0]["extension"] = [{"url": EXT_POA, "valueCodeableConcept": cc("https://www.cms.gov/Medicare/Medicare-Fee-for-Service-Payment/HospitalAcqCond/Coding", "Y")}]
    return eid


def problem(ctx, code, system, display, onset=None, ver="confirmed", key="prob"):
    c = {"resourceType": "Condition", "id": rid(ctx["pid"], key, code),
         "category": [cc("http://terminology.hl7.org/CodeSystem/condition-category", "problem-list-item", "Problem List Item")],
         "clinicalStatus": cc("http://terminology.hl7.org/CodeSystem/condition-clinical", "active" if ver != "refuted" else "inactive"),
         "verificationStatus": cc("http://terminology.hl7.org/CodeSystem/condition-ver-status", ver),
         "code": cc(system, code, display), "subject": ref("Patient", ctx["pid"]),
         "recordedDate": iso(onset or dt.date(2024, 2, 1))}
    if onset:
        c["onsetDateTime"] = iso(onset)
    add(c, "us-quality-core-condition-problems-health-concerns")


def procedure(ctx, d, code, system, display, status="completed", body=None, key="proc", partial=None, period=False, enc=None, claim=False, modifier=None):
    p = {"resourceType": "Procedure", "id": rid(ctx["pid"], key, d, code), "status": status,
         "code": cc(system, code, display), "subject": ref("Patient", ctx["pid"]),
         "performer": [{"actor": ref("Practitioner", ctx["pract"])}],
         "extension": [{"url": EXT_RECORDED, "valueDateTime": dtm(d + dt.timedelta(days=2) if isinstance(d, dt.date) else MP_END, 12)}]}
    if partial:
        p["performedDateTime"] = partial
    elif period:
        p["performedPeriod"] = {"start": dtm(d, 8), "end": dtm(d, 9)}
    else:
        p["performedDateTime"] = dtm(d, 9)
    if body:
        p["bodySite"] = [cc(SCT, body[0], body[1])]
    if enc:
        p["encounter"] = ref("Encounter", enc)
    add(p, "us-quality-core-procedure")
    if claim:
        make_claim(ctx, d, code, display, modifier=modifier)
    return p["id"]


def make_claim(ctx, d, code, display, modifier=None, dx=("Z12.31", "Encounter for screening mammogram for malignant neoplasm of breast")):
    cid = rid(ctx["pid"], "claim", d, code)
    item = {"sequence": 1, "productOrService": cc(CPT, code, display), "servicedDate": iso(d),
            "locationCodeableConcept": cc("https://www.cms.gov/Medicare/Coding/place-of-service-codes/Place_of_Service_Code_Set", "22"),
            "diagnosisSequence": [1]}
    if modifier:
        item["modifier"] = [cc(CPT, modifier)]
    add({"resourceType": "Claim", "id": cid, "status": "active",
         "type": cc("http://terminology.hl7.org/CodeSystem/claim-type", "professional"), "use": "claim",
         "patient": ref("Patient", ctx["pid"]), "billablePeriod": {"start": iso(d), "end": iso(d)},
         "created": iso(d + dt.timedelta(days=5)), "provider": ref("Practitioner", ctx["pract"]),
         "priority": cc("http://terminology.hl7.org/CodeSystem/processpriority", "normal"),
         "insurance": [{"sequence": 1, "focal": True, "coverage": ref("Coverage", ctx["cov_ids"][-1])}],
         "diagnosis": [{"sequence": 1, "diagnosisCodeableConcept": cc(ICD10, dx[0], dx[1])}], "item": [item]},
        "us-quality-core-claim")
    return cid


def saab_obs(ctx, value, status="final"):
    code, disp = ("LA3-6", "Female") if value == "female" else ("LA2-8", "Male")
    add({"resourceType": "Observation", "id": rid(ctx["pid"], "saab"), "status": status,
         "category": [cc("http://terminology.hl7.org/CodeSystem/observation-category", "social-history", "Social History")],
         "code": cc(LOINC, "76689-9", "Sex assigned at birth"), "subject": ref("Patient", ctx["pid"]),
         "effectiveDateTime": iso(ctx["dob"]) if isinstance(ctx["dob"], dt.date) else "1965",
         "valueCodeableConcept": cc(LOINC, code, disp)}, "us-quality-core-simple-observation")


def mammogram(ctx, d=None, form="procedure", status="completed", code=("77067", "Screening mammography, bilateral"), partial=None,
              period=False, report_status="final", tomo=False, claim=False):
    d = d or rand_date(dt.date(2024, 1, 15), dt.date(2025, 11, 30))
    if form == "procedure":
        enc = encounter(ctx, d, ("77067", "Screening mammography"), key="enc-mammo", dx=("Z12.31", "Encounter for screening mammogram for malignant neoplasm of breast"))
        procedure(ctx, d, code[0], CPT, code[1], status=status, partial=partial, period=period, key="mammo", enc=enc, claim=claim)
        if tomo:
            procedure(ctx, d, "77063", CPT, "Screening digital breast tomosynthesis, bilateral", key="tomo", enc=enc)
    elif form == "report":
        add({"resourceType": "DiagnosticReport", "id": rid(ctx["pid"], "mgrpt", d), "status": report_status,
             "category": [cc(LOINC, "LP29684-5", "Radiology")], "code": cc(LOINC, "24606-6", "MG Breast Screening"),
             "subject": ref("Patient", ctx["pid"]), "effectiveDateTime": dtm(d, 9), "issued": dtm(d + dt.timedelta(days=1), 14),
             "performer": [ref("Organization", ctx["fac"][0])],
             "conclusion": "BI-RADS 1: Negative.",
             "presentedForm": [{"contentType": "application/pdf", "title": "Screening mammogram report", "url": f"https://docs.example.org/{ctx['pid']}/mg.pdf"}]},
            "us-quality-core-diagnosticreport-note")
    elif form == "imagingstudy":
        add({"resourceType": "ImagingStudy", "id": rid(ctx["pid"], "img", d), "status": "available",
             "subject": ref("Patient", ctx["pid"]), "started": dtm(d, 9),
             "modality": [{"system": "http://dicom.nema.org/resources/ontology/DCM", "code": "MG"}],
             "procedureCode": [cc(LOINC, "24606-6", "MG Breast Screening")], "numberOfSeries": 1, "numberOfInstances": 4,
             "series": [{"uid": f"2.25.{R.randint(10**15, 10**16)}", "modality": {"system": "http://dicom.nema.org/resources/ontology/DCM", "code": "MG"},
                         "bodySite": {"system": SCT, "code": "76752008", "display": "Breast structure"}}]}, "us-quality-core-imagingstudy")
    elif form == "notdone":
        add({"resourceType": "Procedure", "id": rid(ctx["pid"], "mammo-nd", d), "status": "not-done",
             "extension": [{"url": EXT_RECORDED, "valueDateTime": dtm(d, 11)}],
             "statusReason": cc(SCT, "183944003", "Procedure refused (situation)"),
             "code": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": VS["Mammography"]}], "text": "Not Done Value Set: Mammography"},
             "subject": ref("Patient", ctx["pid"])}, "us-quality-core-procedurenotdone")
    elif form == "notrequested":
        add({"resourceType": "ServiceRequest", "id": rid(ctx["pid"], "mammo-snr", d), "status": "completed", "intent": "order",
             "doNotPerform": True, "extension": [{"url": EXT_DNP_REASON, "valueCodeableConcept": cc(SCT, "410534003", "Not indicated (qualifier value)")}],
             "code": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": VS["Mammography"]}], "text": "Not Done Value Set: Mammography"},
             "subject": ref("Patient", ctx["pid"]), "authoredOn": dtm(d, 10), "requester": ref("Practitioner", ctx["pract"])},
            "us-quality-core-servicenotrequested")
    elif form == "order_only":
        add({"resourceType": "ServiceRequest", "id": rid(ctx["pid"], "mammo-sr", d), "status": "active", "intent": "order", "doNotPerform": False,
             "code": cc(CPT, "77067", "Screening mammography, bilateral"), "subject": ref("Patient", ctx["pid"]),
             "authoredOn": dtm(d, 10), "occurrenceDateTime": iso(d + dt.timedelta(days=21)), "requester": ref("Practitioner", ctx["pract"]),
             "extension": [{"url": EXT_APPROP, "valueCode": "appropriate"}]}, "us-quality-core-servicerequest")


def exclusion(ctx, kind):
    p = ctx["pid"]
    if kind == "bilat_proc":
        procedure(ctx, dt.date(2015, 4, 2), "27865001", SCT, "Bilateral mastectomy", key="bilat")
    elif kind == "bilat_after":
        procedure(ctx, dt.date(2026, 2, 10), "27865001", SCT, "Bilateral mastectomy", key="bilat")
    elif kind == "bilat_eie":
        procedure(ctx, dt.date(2019, 6, 1), "27865001", SCT, "Bilateral mastectomy", status="entered-in-error", key="bilat")
    elif kind == "hx_bilat":
        problem(ctx, "Z90.13", ICD10, "Acquired absence of bilateral breasts and nipples", dt.date(2018, 3, 1))
    elif kind == "hx_refuted":
        problem(ctx, "Z90.13", ICD10, "Acquired absence of bilateral breasts and nipples", dt.date(2018, 3, 1), ver="refuted")
    elif kind == "absent_lr":
        problem(ctx, "Z90.12", ICD10, "Acquired absence of left breast and nipple", dt.date(2016, 5, 1), key="absL")
        problem(ctx, "Z90.11", ICD10, "Acquired absence of right breast and nipple", dt.date(2020, 9, 1), key="absR")
    elif kind == "uni_left":
        procedure(ctx, dt.date(2017, 2, 14), "172043006", SCT, "Unilateral simple mastectomy", body=("7771000", "Left"), key="uniL")
    elif kind == "uni_bilat_site":
        procedure(ctx, dt.date(2017, 2, 14), "172043006", SCT, "Unilateral simple mastectomy", body=("51440002", "Right and left"), key="uniB")
    elif kind in ("two_uni_30", "two_uni_7"):
        d1 = dt.date(2021, 3, 1)
        gap = 30 if kind == "two_uni_30" else 7
        procedure(ctx, d1, "19303", CPT, "Mastectomy, simple, complete", key="uni1", claim=True)
        procedure(ctx, d1 + dt.timedelta(days=gap), "19303", CPT, "Mastectomy, simple, complete", key="uni2", claim=True)
    elif kind == "claim_mod50":
        procedure(ctx, dt.date(2020, 10, 6), "19303", CPT, "Mastectomy, simple, complete", body=("51440002", "Right and left"),
                  key="mod50", claim=True, modifier="50")
    elif kind in ("hospice_enc", "hospice_prior"):
        d = dt.date(2025, 7, 1) if kind == "hospice_enc" else dt.date(2024, 5, 1)
        encounter(ctx, d, ("Q5003", "Hospice care provided in nursing long term care facility"), system=HCPCS, key="hospice")
    elif kind == "hospice_sr":
        add({"resourceType": "ServiceRequest", "id": rid(p, "hospice-sr"), "status": "active", "intent": "order", "doNotPerform": False,
             "code": cc(SCT, "385763009", "Hospice care (regime/therapy)"), "subject": ref("Patient", p),
             "authoredOn": dtm(dt.date(2025, 9, 2)), "requester": ref("Practitioner", ctx["pract"])}, "us-quality-core-servicerequest")
    elif kind == "palliative":
        encounter(ctx, dt.date(2025, 4, 9), ("99213", "Office visit"), key="pall", dx=("Z51.5", "Encounter for palliative care"))
    elif kind in ("frail_ai", "frail_only"):
        problem(ctx, "R54", ICD10, "Age-related physical debility", dt.date(2025, 2, 1), key="frail")
        if kind == "frail_ai":
            for i, d in enumerate([dt.date(2024, 11, 5), dt.date(2025, 3, 12)]):
                encounter(ctx, d, ("99214", "Office visit"), key=f"ai{i}", dx=("I50.9", "Heart failure, unspecified"))
    elif kind == "gac":
        procedure(ctx, dt.date(2022, 8, 3), "19318", CPT, "Breast reduction", key="gac", claim=True)
        problem(ctx, "F64.0", ICD10, "Transsexualism", dt.date(2019, 1, 10), key="gd")


SUPPORT = [  # (profile, builder) used on random subsets so every USQC profile appears
]


def supporting(ctx):
    """Routine clinical content; each block fires with a probability so all USQC profiles are represented."""
    p, d0 = ctx["pid"], rand_date(dt.date(2024, 2, 1), dt.date(2025, 10, 31))
    enc = encounter(ctx, d0, ("99396" if ctx["age"] >= 40 else "99395", "Periodic preventive visit"), key="wellness",
                    dx=(R.choice(["Z00.00", "I10", "E11.9", "E78.5"]), "Visit diagnosis"))
    add({"resourceType": "Observation", "id": rid(p, "bp", d0), "status": "final",
         "category": [cc("http://terminology.hl7.org/CodeSystem/observation-category", "vital-signs", "Vital Signs")],
         "code": cc(LOINC, "8867-4", "Heart rate"), "subject": ref("Patient", p), "encounter": ref("Encounter", enc),
         "effectiveDateTime": dtm(d0), "valueQuantity": {"value": R.randint(58, 96), "unit": "/min", "system": UCUM, "code": "/min"}},
        "us-quality-core-observation-clinical-result")
    if R.random() < 0.6:
        oid = rid(p, "a1c", d0)
        add({"resourceType": "Observation", "id": oid, "status": "final",
             "category": [cc("http://terminology.hl7.org/CodeSystem/observation-category", "laboratory", "Laboratory")],
             "code": cc(LOINC, "4548-4", "Hemoglobin A1c/Hemoglobin.total in Blood"), "subject": ref("Patient", p),
             "effectiveDateTime": dtm(d0), "valueQuantity": {"value": round(R.uniform(4.8, 9.5), 1), "unit": "%", "system": UCUM, "code": "%"}},
            "us-quality-core-observation-lab")
        add({"resourceType": "DiagnosticReport", "id": rid(p, "labrpt", d0), "status": "final",
             "category": [cc("http://terminology.hl7.org/CodeSystem/v2-0074", "LAB", "Laboratory")],
             "code": cc(LOINC, "4548-4", "Hemoglobin A1c panel"), "subject": ref("Patient", p), "effectiveDateTime": dtm(d0),
             "issued": dtm(d0, 16), "result": [ref("Observation", oid)]}, "us-quality-core-diagnosticreport-lab")
    if R.random() < 0.25:
        qr = rid(p, "phq2", d0)
        add({"resourceType": "QuestionnaireResponse", "id": qr, "questionnaire": "http://loinc.org/q/55757-9", "status": "completed",
             "subject": ref("Patient", p), "authored": dtm(d0),
             "item": [{"linkId": "55757-9", "text": "PHQ-2 total score", "answer": [{"valueInteger": R.randint(0, 6)}]}]},
            "us-quality-core-questionnaireresponse")
        add({"resourceType": "Observation", "id": rid(p, "phq2obs", d0), "status": "final",
             "category": [cc("http://terminology.hl7.org/CodeSystem/observation-category", "survey", "Survey")],
             "code": cc(LOINC, "55758-7", "PHQ-2 total score"), "subject": ref("Patient", p), "effectiveDateTime": dtm(d0),
             "valueInteger": R.randint(0, 6), "derivedFrom": [ref("QuestionnaireResponse", qr)]}, "us-quality-core-observation-screening-assessment")
    if R.random() < 0.08:
        add({"resourceType": "Observation", "id": rid(p, "lipid-cx", d0), "status": "cancelled",
             "extension": [{"url": EXT_NOTDONE_REASON, "valueCodeableConcept": cc(SCT, "416432009", "Procedure not wanted (situation)")}],
             "category": [cc("http://terminology.hl7.org/CodeSystem/observation-category", "laboratory")],
             "code": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113883.3.464.1003.198.12.1036"}],
                      "text": "Not Done Value Set: LDL Cholesterol"},
             "subject": ref("Patient", p), "issued": dtm(d0, 15)}, "us-quality-core-observationcancelled")
    if R.random() < 0.35:
        mr = rid(p, "rx", d0)
        add({"resourceType": "MedicationRequest", "id": mr, "status": "active", "intent": "order", "doNotPerform": False,
             "medicationReference": ref("Medication", "med-lisinopril"), "subject": ref("Patient", p), "authoredOn": dtm(d0),
             "requester": ref("Practitioner", ctx["pract"]),
             "dosageInstruction": [{"text": "1 tablet by mouth daily"}]}, "us-quality-core-medicationrequest")
        add({"resourceType": "MedicationDispense", "id": rid(p, "disp", d0), "status": "completed",
             "medicationReference": ref("Medication", "med-lisinopril"), "subject": ref("Patient", p),
             "authorizingPrescription": [ref("MedicationRequest", mr)], "whenHandedOver": dtm(d0 + dt.timedelta(days=1)),
             "quantity": {"value": 30, "unit": "tablet"}}, "us-quality-core-medicationdispense")
        add({"resourceType": "MedicationStatement", "id": rid(p, "medstmt", d0), "status": "active",
             "medicationReference": ref("Medication", "med-lisinopril"), "subject": ref("Patient", p), "dateAsserted": dtm(d0)},
            "us-quality-core-medicationstatement")
    if R.random() < 0.05:
        add({"resourceType": "MedicationRequest", "id": rid(p, "rx-nr", d0), "status": "completed", "intent": "order", "doNotPerform": True,
             "medicationCodeableConcept": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113883.3.117.1.7.1.201"}],
                                           "text": "Not Done Value Set: Statin"},
             "subject": ref("Patient", p), "authoredOn": dtm(d0), "reasonCode": [cc(SCT, "62014003", "Adverse reaction to drug")]},
            "us-quality-core-medicationnotrequested")
        add({"resourceType": "MedicationDispense", "id": rid(p, "disp-dec", d0), "status": "declined",
             "extension": [{"url": EXT_RECORDED, "valueDateTime": dtm(d0)}],
             "statusReasonCodeableConcept": cc(SCT, "183966005", "Drug treatment not indicated (situation)"),
             "medicationCodeableConcept": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113883.3.117.1.7.1.201"}],
                                           "text": "Not Done Value Set: Statin"}, "subject": ref("Patient", p)}, "us-quality-core-medicationdispensedeclined")
    if R.random() < 0.06:
        e2 = encounter(ctx, d0 + dt.timedelta(days=40), ("32485007", "Hospital admission"), system=SCT, cls="IMP", key="inpt",
                       dx=("J18.9", "Pneumonia, unspecified organism"), end=d0 + dt.timedelta(days=44))
        add({"resourceType": "MedicationAdministration", "id": rid(p, "mar", d0), "status": "completed",
             "medicationCodeableConcept": cc(RXN, "1665021", "ceftriaxone 1000 MG Injection"), "subject": ref("Patient", p),
             "context": ref("Encounter", e2), "effectiveDateTime": dtm(d0 + dt.timedelta(days=40), 14)}, "us-quality-core-medicationadministration")
        add({"resourceType": "MedicationAdministration", "id": rid(p, "mar-nd", d0), "status": "not-done",
             "extension": [{"url": EXT_RECORDED, "valueDateTime": dtm(d0 + dt.timedelta(days=41), 8)}],
             "statusReason": [cc(SCT, "182890002", "Patient requests alternative treatment (finding)")],
             "medicationCodeableConcept": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113762.1.4.1110.19"}],
                                           "text": "Not Done Value Set: VTE prophylaxis"},
             "subject": ref("Patient", p), "effectiveDateTime": dtm(d0 + dt.timedelta(days=41), 8)}, "us-quality-core-medicationadministrationnotdone")
        add({"resourceType": "NutritionOrder", "id": rid(p, "diet", d0), "status": "active", "intent": "order", "patient": ref("Patient", p),
             "encounter": ref("Encounter", e2), "dateTime": dtm(d0 + dt.timedelta(days=40), 12),
             "oralDiet": {"type": [cc(SCT, "160670007", "Diabetic diet")]}}, "us-quality-core-nutritionorder")
        add({"resourceType": "AdverseEvent", "id": rid(p, "ae", d0), "actuality": "actual", "subject": ref("Patient", p),
             "event": cc(SCT, "422587007", "Nausea"), "date": dtm(d0 + dt.timedelta(days=42)), "encounter": ref("Encounter", e2),
             "recordedDate": dtm(d0 + dt.timedelta(days=42), 15)}, "us-quality-core-adverseevent")
    if R.random() < 0.3:
        imm = rid(p, "flu", d0)
        add({"resourceType": "Immunization", "id": imm, "status": "completed", "vaccineCode": cc(CVX, "197", "Influenza, high-dose, quadrivalent"),
             "patient": ref("Patient", p), "occurrenceDateTime": dtm(dt.date(2024, 10, R.randint(1, 28))), "primarySource": True},
            "us-quality-core-immunization")
        if R.random() < 0.3:
            add({"resourceType": "ImmunizationEvaluation", "id": rid(p, "immeval", d0), "status": "completed", "patient": ref("Patient", p),
                 "date": dtm(dt.date(2024, 11, 1)), "targetDisease": cc(SCT, "6142004", "Influenza"), "immunizationEvent": ref("Immunization", imm),
                 "doseStatus": cc("http://terminology.hl7.org/CodeSystem/immunization-evaluation-dose-status", "valid", "Valid")},
                "us-quality-core-immunizationevaluation")
    elif R.random() < 0.08:
        add({"resourceType": "Immunization", "id": rid(p, "flu-nd", d0), "status": "not-done",
             "statusReason": cc(SCT, "182895007", "Drug declined by patient"),
             "vaccineCode": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113883.3.526.3.1254"}],
                             "text": "Not Done Value Set: Influenza vaccine"},
             "patient": ref("Patient", p), "occurrenceDateTime": dtm(dt.date(2024, 10, 15)), "recorded": dtm(dt.date(2024, 10, 15))},
            "us-quality-core-immunizationnotdone")
    if R.random() < 0.06:
        add({"resourceType": "ImmunizationRecommendation", "id": rid(p, "immrec"), "patient": ref("Patient", p), "date": dtm(dt.date(2025, 9, 1)),
             "recommendation": [{"vaccineCode": [cc(CVX, "309", "COVID-19 vaccine, mRNA")],
                                 "forecastStatus": cc("http://terminology.hl7.org/CodeSystem/immunization-recommendation-status", "due")}]},
            "us-quality-core-immunizationrecommendation")
    if R.random() < 0.12:
        add({"resourceType": "AllergyIntolerance", "id": rid(p, "alg"), "patient": ref("Patient", p),
             "clinicalStatus": cc("http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", "active"),
             "verificationStatus": cc("http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", "confirmed"),
             "code": R.choice([cc(RXN, "7980", "Penicillin G"), cc(SCT, "111088007", "Latex (substance)")])}, "us-quality-core-allergyintolerance")
    if R.random() < 0.1:
        add({"resourceType": "FamilyMemberHistory", "id": rid(p, "fmh"), "status": "completed", "patient": ref("Patient", p),
             "relationship": cc("http://terminology.hl7.org/CodeSystem/v3-RoleCode", R.choice(["MTH", "SIS"])),
             "condition": [{"code": cc(SCT, "254837009", "Malignant neoplasm of breast")}]}, "us-quality-core-familymemberhistory")
    if R.random() < 0.06:
        g = rid(p, "goal")
        add({"resourceType": "Goal", "id": g, "lifecycleStatus": "active", "description": {"text": "HbA1c below 7%"}, "subject": ref("Patient", p),
             "target": [{"measure": cc(LOINC, "4548-4"), "detailQuantity": {"value": 7, "unit": "%", "system": UCUM, "code": "%"}}]}, "us-quality-core-goal")
        ct = rid(p, "careteam")
        add({"resourceType": "CareTeam", "id": ct, "status": "active", "subject": ref("Patient", p),
             "participant": [{"role": [cc(SCT, "446050000", "Primary care physician")], "member": ref("Practitioner", ctx["pract"])}]}, "us-quality-core-careteam")
        add({"resourceType": "CarePlan", "id": rid(p, "careplan"), "status": "active", "intent": "plan",
             "category": [cc("http://hl7.org/fhir/us/core/CodeSystem/careplan-category", "assess-plan", "Assessment and Plan of Treatment")],
             "subject": ref("Patient", p), "careTeam": [ref("CareTeam", ct)], "goal": [ref("Goal", g)],
             "text": {"status": "generated", "div": "<div xmlns=\"http://www.w3.org/1999/xhtml\">Diabetes management plan</div>"}}, "us-quality-core-careplan")
        add({"resourceType": "Flag", "id": rid(p, "flag"), "status": "active", "code": cc(SCT, "699653001", "Fall risk"), "subject": ref("Patient", p)},
            "us-quality-core-flag")
    if R.random() < 0.05:
        dev = rid(p, "dev")
        add({"resourceType": "Device", "id": dev, "patient": ref("Patient", p), "type": cc(SCT, "58938008", "Wheelchair"), "status": "active"},
            "us-quality-core-device")
        add({"resourceType": "DeviceUseStatement", "id": rid(p, "dus"), "status": "active", "subject": ref("Patient", p), "device": ref("Device", dev)},
            "us-quality-core-deviceusestatement")
        add({"resourceType": "DeviceRequest", "id": rid(p, "devreq"), "status": "completed", "intent": "order",
             "codeCodeableConcept": cc(SCT, "58938008", "Wheelchair"), "subject": ref("Patient", p), "authoredOn": dtm(d0)}, "us-quality-core-devicerequest")
        add({"resourceType": "BodyStructure", "id": rid(p, "bodystr"), "active": True, "patient": ref("Patient", p),
             "location": cc(SCT, "61685007", "Lower limb structure")}, "us-quality-core-bodystructure")
    if R.random() < 0.03:
        add({"resourceType": "DeviceRequest", "id": rid(p, "devreq-nr"), "status": "completed", "intent": "original-order",
             "extension": [{"url": EXT_DNP_REASON, "valueCodeableConcept": cc(SCT, "410534003", "Not indicated (qualifier value)")}],
             "modifierExtension": [{"url": "http://hl7.org/fhir/5.0/StructureDefinition/extension-DeviceRequest.doNotPerform", "valueBoolean": True}],
             "codeCodeableConcept": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113883.3.117.1.7.1.230"}],
                                     "text": "Not Done Value Set: Venous foot pumps"},
             "subject": ref("Patient", p), "authoredOn": dtm(d0)}, "us-quality-core-devicenotrequested")
    if R.random() < 0.08:
        cr = rid(p, "commreq")
        add({"resourceType": "CommunicationRequest", "id": cr, "status": "completed", "subject": ref("Patient", p),
             "payload": [{"contentString": "Reminder: you are due for a screening."}], "authoredOn": dtm(d0)}, "us-quality-core-communicationrequest")
        if R.random() < 0.7:
            add({"resourceType": "Communication", "id": rid(p, "comm"), "status": "completed", "subject": ref("Patient", p), "basedOn": [ref("CommunicationRequest", cr)],
                 "sent": dtm(d0 + dt.timedelta(days=1)), "medium": [cc("http://terminology.hl7.org/CodeSystem/v3-ParticipationMode", "WRITTEN")],
                 "payload": [{"contentString": "Screening reminder letter sent."}]}, "us-quality-core-communication")
        else:
            add({"resourceType": "Communication", "id": rid(p, "comm-nd"), "status": "not-done",
                 "extension": [{"url": EXT_RECORDED, "valueDateTime": dtm(d0 + dt.timedelta(days=2))}],
                 "statusReason": cc(SCT, "281399006", "Unable to contact patient"), "subject": ref("Patient", p),
                 "topic": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113762.1.4.1116.585"}],
                           "text": "Not Done Value Set: Outreach communication"}}, "us-quality-core-communicationnotdone")
    if R.random() < 0.05:
        t = rid(p, "task")
        add({"resourceType": "Task", "id": t, "identifier": [{"system": "urn:sonian:task", "value": t[:8]}], "status": "completed",
             "intent": "order", "priority": "routine", "code": cc(SCT, "430193006", "Medication reconciliation"), "for": ref("Patient", p),
             "executionPeriod": {"start": dtm(d0), "end": dtm(d0, 11)}}, "us-quality-core-task")
        add({"resourceType": "Task", "id": rid(p, "task-rej"), "status": "rejected", "intent": "proposal",
             "statusReason": cc(SCT, "275936005", "Patient noncompliance - general"),
             "code": {"extension": [{"url": EXT_NOTDONE_VS, "valueCanonical": "http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.113762.1.4.1096.11"}],
                      "text": "Not Done Value Set: Medication reconciliation"},
             "focus": ref("Task", t), "for": ref("Patient", p), "executionPeriod": {"start": dtm(d0), "end": dtm(d0)}}, "us-quality-core-taskrejected")
    if R.random() < 0.04:
        add({"resourceType": "RelatedPerson", "id": rid(p, "rp"), "active": True, "patient": ref("Patient", p),
             "relationship": [cc("http://terminology.hl7.org/CodeSystem/v3-RoleCode", "DAU", "daughter")], "name": [{"family": "Rivera", "given": ["Ana"]}]},
            "us-quality-core-relatedperson")
    if R.random() < 0.04:
        sr = rid(p, "colo-sr")
        add({"resourceType": "ServiceRequest", "id": sr, "status": "completed", "intent": "order", "doNotPerform": False,
             "code": cc(CPT, "45378", "Colonoscopy, diagnostic"), "subject": ref("Patient", p), "authoredOn": dtm(d0),
             "extension": [{"url": EXT_ELECTIVE, "valueBoolean": True}]}, "us-quality-core-servicerequest")
        cl = make_claim(ctx, d0 + dt.timedelta(days=30), "45378", "Colonoscopy, diagnostic", dx=("Z12.11", "Encounter for screening for malignant neoplasm of colon"))
        add({"resourceType": "ClaimResponse", "id": rid(p, "claimresp"), "status": "active",
             "type": cc("http://terminology.hl7.org/CodeSystem/claim-type", "professional"), "use": "preauthorization",
             "patient": ref("Patient", p), "created": dtm(d0 + dt.timedelta(days=3)), "insurer": ref("Organization", "payer-com"),
             "request": ref("Claim", cl), "outcome": "complete"}, "us-quality-core-claimresponse")


# ------------------------------------------------------------------ population
def expected(ctx, edge_id, desc, ov, has_mammo_evidence):
    """Answer key from the scenario design (BCS-E MY2025 rules as implemented in this project)."""
    g, age = ctx["gender"], ctx["age"]
    female = g == "female" or (ov.get("saab") == "female" and ov.get("saab_status", "final") != "entered-in-error")
    age_ok = ov.get("dob_partial") is None and 42 <= age <= 74
    ip = female and age_ok
    ce = ce_met(ctx["spans"])
    ex = ov.get("excl")
    excl_true = {"bilat_proc", "hx_bilat", "absent_lr", "uni_bilat_site", "two_uni_30", "claim_mod50", "hospice_enc", "hospice_sr",
                 "palliative", "deceased", "gac"}
    excluded = ex in excl_true or (ex == "frail_ai" and age >= 66)
    elig = ip and ce
    num = elig and not excluded and has_mammo_evidence
    answer.append({"patient_id": ctx["pid"], "edge_case": edge_id or "", "description": desc, "gender": g,
                   "sex_assigned_at_birth": ov.get("saab", ""), "birth_date": ov.get("dob_partial") or iso(ctx["dob"]),
                   "age_at_mp_end": age if not ov.get("dob_partial") else "", "initial_population": int(ip),
                   "continuous_enrollment": int(ce), "denominator_eligible": int(elig), "excluded": int(elig and excluded),
                   "exclusion_reason": (ex or "") if elig and excluded else "", "denominator": int(elig and not excluded),
                   "numerator": int(num)})


def main():
    n = 0
    # 1) scripted edge cases
    for eid, count, desc, ov in EDGES:
        for _ in range(count):
            n += 1
            age = ov.get("age") or R.randint(45, 70)
            ctx = build_patient(n, {"gender": "female", "age": age}, eid, ov)
            if ov.get("saab"):
                saab_obs(ctx, ov["saab"], ov.get("saab_status", "final"))
            form = ov.get("mammo_form", "procedure")
            has_ev = False
            if any(k in ov for k in ("mammo", "mammo_date", "mammo_form", "mammo_status", "mammo_code", "mammo_partial", "mammo_period", "mammo_claim")):
                md = ov.get("mammo_date") or (dt.date(2025, 3, 3) if ov.get("mammo_period") else None)
                mammogram(ctx, md, form=form, status=ov.get("mammo_status", "completed"),
                          code=ov.get("mammo_code", ("77067", "Screening mammography, bilateral")), partial=ov.get("mammo_partial"),
                          period=ov.get("mammo_period", False), report_status=ov.get("report_status", "final"), tomo=ov.get("tomo", False),
                          claim=ov.get("mammo_claim", False))
                d_ok = md is None or LOOKBACK <= md <= MP_END
                part = ov.get("mammo_partial")
                if part:
                    d_ok = part >= "2023-10" and len(part) >= 7
                has_ev = (form in ("procedure", "report") and ov.get("mammo_status", "completed") == "completed"
                          and ov.get("report_status", "final") == "final" and not ov.get("mammo_not_vs") and d_ok)
            elif eid.startswith(("EXC", "ENR")) and R.random() < 0.6:
                mammogram(ctx)
                has_ev = True
            if ov.get("excl"):
                exclusion(ctx, ov["excl"])
            supporting(ctx)
            expected(ctx, eid, desc, ov, has_ev)
    # 2) routine population to n=1000
    while n < 1000:
        n += 1
        u = R.random()
        gender = "female" if u < 0.56 else "male" if u < 0.97 else R.choice(["other", "unknown"])
        age = R.choice([R.randint(18, 41), R.randint(42, 74), R.randint(42, 74), R.randint(42, 74), R.randint(75, 90)])
        ctx = build_patient(n, {"gender": gender, "age": age})
        if R.random() < 0.35:
            saab_obs(ctx, "female" if gender in ("female", "unknown") else "male")
        has_ev = False
        if gender == "female" and age >= 40 and R.random() < 0.68:
            form = "report" if R.random() < 0.15 else "procedure"
            mammogram(ctx, form=form, claim=(form == "procedure" and R.random() < 0.6),
                      code=R.choice([("77067", "Screening mammography, bilateral")] * 4 + [("77066", "Diagnostic mammography, bilateral")]))
            has_ev = True
            if R.random() < 0.2:
                mammogram(ctx, form="imagingstudy")
        if R.random() < 0.3:
            problem(ctx, *R.choice([("I10", ICD10, "Essential (primary) hypertension"), ("E11.9", ICD10, "Type 2 diabetes mellitus without complications"),
                                     ("E78.5", ICD10, "Hyperlipidemia, unspecified"), ("J45.909", ICD10, "Unspecified asthma, uncomplicated")]),
                    onset=rand_date(dt.date(2010, 1, 1), dt.date(2024, 12, 31)), key="chronic")
        if gender == "male" and age >= 50 and R.random() < 0.2:
            procedure(ctx, rand_date(dt.date(2024, 1, 1), dt.date(2025, 10, 1)), "45378", CPT, "Colonoscopy, diagnostic", key="colo", claim=True)
        supporting(ctx)
        expected(ctx, "", "Routine member", {}, has_ev)
    write()


def write():
    OUT.mkdir(parents=True, exist_ok=True)
    ttime = "2026-11-06T12:00:00Z"
    output = []
    for rt in sorted(store):
        path = OUT / f"{rt}.ndjson"
        with open(path, "w") as f:
            for r in store[rt]:
                f.write(json.dumps(r, separators=(",", ":")) + "\n")
        output.append({"type": rt, "url": BASE_URL + f"{rt}.ndjson", "count": len(store[rt])})
    manifest = {"transactionTime": ttime, "request": "https://bulk.example.org/fhir/$export?_type=" + ",".join(sorted(store)),
                "requiresAccessToken": False, "output": output, "error": [],
                "extension": {"https://sonian.io/bulk/dataset": "BCS-E MY2025 synthetic test population n=1000 (US Quality Core 0.5.0)"}}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2))
    import csv
    with open(OUT.parent / "answer_key_bcse_my2025.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(answer[0]))
        w.writeheader()
        w.writerows(answer)
    json.dump(dict(profiles_used), open(OUT.parent / "_profiles_used.json", "w"), indent=1)
    print("resources:", sum(len(v) for v in store.values()), "types:", len(store), "profiles:", len(profiles_used))


if __name__ == "__main__":
    main()
